/**This class will perform certain operations based on user input, 
1 to Sign up, 2 to login, 3 to booking, 4 to exit*/

package com.ars;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class ReserveMainOperation {

	public static void main(String[] args) {
		int menu = 0;
		String id = "";
		while (menu != 4) {
			System.out.println("\n*********Welcome to Airline Reservation System***********");
			System.out.println("Authentication*");
			System.out.println("-> Enter Your Choice : \n 1:SignUp \n 2:Login \n 3:AirlineBooking \n 4:Exit \n");
			Scanner sc = new Scanner(System.in);
			menu = sc.nextInt();
			switch (menu) {
			case 1:
				SignupClass.Register();//call Register method in SignUpClass to signUp new user
				break;
			case 2:
				id = LoginClass.main();//call main method in LoginClass
				if (id != null) {
					System.out.println("Login Success!!");
					System.out.println("Go for your booking:)");
				} else {
					System.out.println("Wrong Creditials ! Enter again...");
				}
				break;
			case 3:
				System.out.println("Airline Booking");
				AirlineHomePage.Booking(id);//call Booking method for booking in different airlines
				break;
			case 4:
				System.out.println("Logged out successfully!!!");//this will exit out of the process
			}

		}
	}
}
		
	
	











	

	

	


