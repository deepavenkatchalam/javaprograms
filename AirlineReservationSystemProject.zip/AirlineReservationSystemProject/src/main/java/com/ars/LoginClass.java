/**
* In this login process the back end we created one Emailid and password;
* this class will verify user credentials, whether they have an existing account or not
*
*/

package com.ars;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class LoginClass {

	public static String main(){
		boolean loginSuccess = false;
	
		String id1 = "", pass = "";
		String id = "", password = "";
		Scanner sc = new Scanner(System.in);
		System.out.println();
		System.out.println("Enter EmailID");
		id = sc.nextLine();
		System.out.println("Enter Password:");
		password = sc.nextLine();
		try {
			//jdbc connection
			Connection conn = DatabaseConnections.getConnection();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("Select *from login");
			while (rs.next()) {
				id1 = rs.getString(1);
				pass = rs.getString(2);
				if (id.equals(id1) && password.equals(pass)) {
					loginSuccess = true;
					return id1;
				} else
					loginSuccess = false;
			}
		} catch (Exception e) {

			System.out.println(e);
		}
		return null;
	}

}