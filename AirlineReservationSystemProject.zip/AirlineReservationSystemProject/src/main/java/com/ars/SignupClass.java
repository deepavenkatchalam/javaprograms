/** In this Signupclass,the backend we created one email,name and password;
 * this class will implement new user sign up steps with Authentication
 */
package com.ars;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class SignupClass {

	public static void Register() {
		int loop = 0;
		int code = 0;
		String id = "", password = "", name = "";
		Scanner sc = new Scanner(System.in);
		//enter the captcha code to proceed
		System.out.println("Signup:If you want to Signup enter the given Captcha[8008]: \n");
		System.out.println("Enter your captcha code to proceed:\n");
		code = sc.nextInt();
		if (code == 8008) {
			Scanner data = new Scanner(System.in);
			System.out.println("Enter EmailID:");
			id = data.nextLine();
			System.out.println("Enter password:");
			password = data.nextLine();
			System.out.println("enter your name");
			name = data.nextLine();
			try {
				//creating connection to connect database
				Connection conn = DatabaseConnections.getConnection();
				//creating insert query to insert new users
				String query = "insert into signup(id,password,name)" + "values(?,?,?)";
				String query1 = "insert into login(id,password)" + "values(?,?)";
				PreparedStatement ps = conn.prepareStatement(query);
				PreparedStatement ps1 = conn.prepareStatement(query1);
				ps.setString(1, id);
				ps.setString(2, password);
				ps.setString(3, name);
				ps1.setString(1, id);
				ps1.setString(2, password);
				int i = ps.executeUpdate();
				ps1.executeUpdate();
				if (i > 0) {
					System.out.println("\nData inserted...\n");
				} else {
					System.out.println("\nData not inserted...");
				}
				System.out.println("now click login..!!");

			} catch (Exception e) {
				System.out.println(e);
			}
		} else {
			System.out.println("\nWrong Captcha code*.\n");
			return;
		}
	}
}







